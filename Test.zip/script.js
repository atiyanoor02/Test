document.addEventListener("DOMContentLoaded", function () 
{
const taskInput = document.getElementById("task");
const addButton = document.getElementById("add");
const taskList = document.getElementById("task-list");
addButton.addEventListener("click", function () 
{
const taskText = taskInput.value.trim();
if (taskText !== "") 
{
const taskItem = document.createElement("li");
taskItem.textContent = taskText;
const removeButton = document.createElement("button");
removeButton.textContent = "Remove";
removeButton.addEventListener("click", function () 
{
taskItem.remove();
}
);
taskItem.appendChild(removeButton);
taskItem.addEventListener("click", function () 
{
taskItem.classList.toggle("completed");
}
);
taskList.appendChild(taskItem);
taskInput.value = "";
}
}
);
}
);